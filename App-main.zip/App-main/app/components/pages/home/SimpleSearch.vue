<script lang="ts" setup>
  import { CheckIcon, MagnifyingGlassIcon } from '@heroicons/vue/20/solid'
  import { watchDebounced } from '@vueuse/core'
  import { abbreviateNumber } from 'js-abbreviation-number'
  import Tag from '~/assets/js/tag.dto'

  const props = defineProps<{
    tagResults: Tag[]
  }>()

  const emit = defineEmits<{
    searchTag: [tag: string]

    submit: [payload: string | undefined]
  }>()

  const { t } = useI18n()

  const selectedTag = ref<Tag | undefined>()

  watch(selectedTag, () => onSubmitted())

  const searchQuery = shallowRef('')

  // Change event
  function onComboboxInputChange(event: Event) {
    if (!(event.target instanceof HTMLInputElement)) {
      return
    }

    let value = event.target.value

    value = value.trim()

    // Replace empty spaces with underscores
    value = value.replace(/\s/g, '_')

    searchQuery.value = value
  }

  watchDebounced(searchQuery, (value) => onSearchChange(value), { debounce: 350 })

  function onSearchChange(tag: string) {
    tag = tag.trim()

    if (!tag || tag === '') {
      return
    }

    emit('searchTag', tag)
  }

  const customTagFromQuery = computed(() => {
    const tag = searchQuery.value

    if (!tag || tag === '') {
      return null
    }

    // If the tag is already in tagResults, return null
    if (props.tagResults.some((tagResult) => tagResult.name === tag)) {
      return null
    }

    return new Tag({ name: tag })
  })

  function onSubmitted() {
    emit('submit', selectedTag.value?.name)
  }

  function getTagName(tag: unknown) {
    return typeof tag === 'object' && tag !== null && 'name' in tag ? String(tag.name ?? '') : ''
  }
</script>

<template>
  <!--  Search & Actions -->
  <section>
    <!-- Search -->
    <!-- TODO: Use Float to fix transparency issues-->
    <HeadlessCombobox v-model="selectedTag">
      <div class="group relative">
        <!-- Icon -->
        <div class="group pointer-events-none absolute inset-y-0 left-0 flex items-center rounded-l-md px-2">
          <MagnifyingGlassIcon
            aria-hidden="true"
            class="h-5 w-5 text-base-content group-hover:text-base-content-hover"
          />
        </div>

        <!-- Input -->
        <HeadlessComboboxInput
          :display-value="getTagName"
          class="w-full rounded-full border-0 bg-transparent px-9 py-2 text-base-content-highlight ring-1 ring-base-0/20 ring-inset hover:hover-bg-util hover:hover-text-util focus-visible:focus-outline-util sm:text-sm"
          :placeholder="t('search.placeholderWithExample')"
          @change="onComboboxInputChange"
        />

        <!-- Button -->
        <!--        <HeadlessComboboxButton class="absolute inset-y-0 right-0 flex items-center rounded-r-md px-2">-->
        <!--          <ChevronUpDownIcon class="h-5 w-5 text-base-content group-hover:text-base-content-hover" />-->
        <!--        </HeadlessComboboxButton>-->

        <!-- Options -->
        <HeadlessComboboxOptions
          class="absolute z-20 mt-2 max-h-72 w-full overflow-auto rounded-md bg-base-1000 py-1 text-base ring-1 ring-base-0/20 sm:text-sm"
        >
          <!-- Custom option -->
          <!-- TODO: History based -->
          <!-- TODO: Basic common queries, e.g. minecraft, brawl_stars, etc. -->
          <HeadlessComboboxOption
            v-if="customTagFromQuery"
            v-slot="{ active, selected }"
            :value="customTagFromQuery"
          >
            <div
              :class="[active ? 'bg-base-0/20 text-base-content-highlight' : 'text-base-content']"
              class="relative cursor-default py-2 pl-8 select-none"
            >
              <span :class="['block truncate', selected && 'font-semibold']">
                {{ t('search.searchTagOption', { tag: customTagFromQuery.name }) }}
              </span>

              <span
                v-if="selected"
                class="absolute inset-y-0 left-0 flex items-center pl-1.5 text-base-content-highlight"
              >
                <CheckIcon
                  aria-hidden="true"
                  class="h-5 w-5"
                />
              </span>
            </div>
          </HeadlessComboboxOption>

          <!-- Options -->
          <HeadlessComboboxOption
            v-for="tag in tagResults"
            :key="tag.name"
            v-slot="{ active, selected }"
            :value="tag"
          >
            <div
              :class="[active ? 'bg-base-0/20 text-base-content-highlight' : 'text-base-content']"
              class="relative cursor-default py-2 pr-12 pl-8 select-none"
            >
              <!-- Check icon -->
              <span
                v-if="selected"
                class="absolute inset-y-0 left-0 flex items-center pl-1.5 text-base-content-highlight"
              >
                <CheckIcon
                  aria-hidden="true"
                  class="h-5 w-5"
                />
              </span>

              <!-- Tag -->
              <span :class="['block truncate', selected && 'font-semibold']">
                {{ tag.name }}
              </span>

              <!-- Tag count -->
              <div class="absolute inset-y-0 right-0 flex items-center gap-2 pr-4">
                <span v-if="tag.count">
                  {{ abbreviateNumber(tag.count, 0) }}
                </span>
              </div>
            </div>
          </HeadlessComboboxOption>
        </HeadlessComboboxOptions>
      </div>
    </HeadlessCombobox>
  </section>
</template>
