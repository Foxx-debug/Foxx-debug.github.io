import randomWeightedChoice from 'random-weighted-choice'

/**
 * Sum of all weights must be 1.0
 */
export const popunderProviders = [
  /**
   * ExoClick
   * Pros:
   * Cons:
   */
  // {
  //   id: '',
  //   weight: 1,
  // },
  /**
   * Adsession
   * Pros:
   * Cons:
   */
  // {
  //   id: '/js/popunder.js?v=7',
  //   weight: 1,
  // },
  /**
   * HilltopAds
   * Pros: Good min payout (100) | Counts more impressions than others w/ same traffic?
   * Cons: Not fixed CPM (~1.6 avg, swings a lot)
   */
  {
    key: 'hilltop',
    label: 'HilltopAds',
    id: 'https://yellowishgather.com/c.D/9v6/bW2/5aleSRW/Qj9SNojrA/zWMxTuk_zvNoiJ0S2kMgDBMux_OXTCMU3Z',
    weight: 0.55
  },
  /**
   * Clickadu
   * Pros: Good CPM (~2.1)
   * Cons: Does not count visits well | Clears console
   */
  {
    key: 'clickadu',
    label: 'Clickadu',
    id: '/js/popunder2.js?v=10',
    weight: 0.05
  },
  /**
   * AdMaven
   * Pros: Good CPM (3.5)
   * Cons: Low Revenue (30) | Impression count lower than everybody else (less overall revenue) | Sometimes replaces current tab instead of opening in new tab | Possible malware: ads open requests to social media login
   */
  // {
  //   id: 'https://dpjf9a2rbjbvp.cloudfront.net/?afjpd=1255038',
  //   weight: 0.25
  // },
  /**
   * AdsCarat
   * Pros: Great CPM (2.5)
   * Cons: Low Revenue (25) | Does not count visits well | Reloads website once?
   */
  // {
  //   id: 'https://hp.scrannyplacebo.com/rMGqiS1acWcIq4LyI/oQRmJ',
  //   weight: 1
  // },
  /**
   * Profiton
   * Pros: Good CPM (~2.15) | Counts visits well
   * Cons: Observed abusive repeat popunders on mobile after nearly every click
   */
  {
    key: 'profiton',
    label: 'Profiton',
    id: 'https://pb.burnetsasgmt.com/rjrr1lrmhPVU/140809',
    weight: 0.25
  },
  /**
   * AdsTerra
   * Pros: Good CPM (~2.5)
   * Cons: Observed replacing current page instead of opening popunder, losing user results
   */
  {
    key: 'adsterra',
    label: 'AdsTerra',
    id: 'https://benchform.org/1/a2bb432972963284b6754dd20c826521',
    weight: 0.15
  }
] as const satisfies readonly { key: string; label: string; id: string; weight: number }[]

export type PopunderProvider = (typeof popunderProviders)[number]
export type PopunderProviderKey = PopunderProvider['key']

export const popunderProviderKeys = popunderProviders.map(({ key }) => key)
export const popunderProviderModes = ['random', ...popunderProviderKeys] as const
export type PopunderProviderMode = (typeof popunderProviderModes)[number]

export const popunderProviderChoices = popunderProviders.map(({ id, weight }) => ({ id, weight }))

export const pushAdProviders = [
  /**
   * PartnersHouse
   * Pros: Good min payout
   * Cons: Low CPM (~0.4)
   */
  // {
  //   key: 'partnershouse',
  //   label: 'PartnersHouse',
  //   id: 'https://hotbsizovu.today/process.js?id=1300335215&p1=sub1&p2=sub2&p3=sub3&p4=sub4',
  //   weight: 0.3
  // },
  /**
   * HilltopAds
   * Pros:
   * Cons: Low CPM (~1.96)
   */
  // {
  //   key: 'hilltop',
  //   label: 'HilltopAds',
  //   id: '\\/\\/ellipticaltrack.com\\/b\\/XeV.sad\\/GJlb0jYvWxcR\\/HewmG9ou\\/ZWUXlukZPMTJY_yMOQTBQe5VMsjVI\\/tuNbjOIh5MNDDpkryvMSwO',
  //   weight: 0.15
  // },
  /**
   * Clickadu
   * Pros:
   * Cons: Low CPM (~0.3)
   */
  // {
  //   key: 'clickadu',
  //   label: 'Clickadu',
  //   id: '/js/in_page_push_ads.js?v=1',
  //   weight: 0.2
  // },
  /**
   * AdsCarat
   * Pros:
   * Cons: Low CPM (~0.50)
   */
  // {
  //   key: 'adscarat',
  //   label: 'AdsCarat',
  //   id: '//jn.astelicbanes.com/sgC9H1j3tpX/121206',
  //   weight: 0.15
  // },
  /**
   * EvaDav
   * Pros: Fixed weekly pay
   * Cons: Low revenue
   */
  {
    key: 'evadav',
    label: 'EvaDav',
    id: 'https://udzpel.com/pw/waWQiOjExOTMwMzUsInNpZCI6MTQwNzY1NSwid2lkIjo2ODMzODcsInNyYyI6Mn0=eyJ.js',
    weight: 0.48
  },
  /**
   * AdMaven
   * Pros: Good CPM (~5.45)
   * Cons: Does not count visits well | Re-opens after closing
   */
  {
    key: 'admaven',
    label: 'AdMaven',
    id: 'https://dpjf9a2rbjbvp.cloudfront.net/?afjpd=1255040',
    weight: 0.05
  },
  /**
   * AdsTerra
   * Pros: Good revenue
   * Cons: Low CPM (~0.63)
   */
  {
    key: 'adsterra',
    label: 'AdsTerra',
    id: 'https://biomanos.org/14/4222908c1f4cbb803a92284f2608eed3',
    weight: 0.47
  }
] as const satisfies readonly { key: string; label: string; id: string; weight: number }[]

export type PushAdProvider = (typeof pushAdProviders)[number]
export type PushAdProviderKey = PushAdProvider['key']

export const pushAdProviderKeys = pushAdProviders.map(({ key }) => key)
export const pushAdProviderModes = ['random', ...pushAdProviderKeys] as const
export type PushAdProviderMode = (typeof pushAdProviderModes)[number]

const pushAdProviderChoices = pushAdProviders.map(({ id, weight }) => ({ id, weight }))

export function getPopunderProviderByKey(key: PopunderProviderKey): PopunderProvider {
  return popunderProviders.find((provider) => provider.key === key) ?? popunderProviders[0]!
}

export function parsePopunderProviderMode(value: unknown): PopunderProviderMode {
  return typeof value === 'string' && popunderProviderModes.includes(value as PopunderProviderMode)
    ? (value as PopunderProviderMode)
    : 'random'
}

export function getPushAdProviderByKey(key: PushAdProviderKey): PushAdProvider {
  return pushAdProviders.find((provider) => provider.key === key) ?? pushAdProviders[0]!
}

export function parsePushAdProviderMode(value: unknown): PushAdProviderMode {
  return typeof value === 'string' && pushAdProviderModes.includes(value as PushAdProviderMode)
    ? (value as PushAdProviderMode)
    : 'random'
}

export function selectRandomPopunderProviderScript() {
  return randomWeightedChoice(popunderProviderChoices)
}

export function selectRandomPushAdProviderScript() {
  return randomWeightedChoice(pushAdProviderChoices)
}

export default function () {
  const popunderScript = useState<string>('popunder-script', () => '')
  const pushScript = useState<string>('push-notification-script', () => '')

  // Load popunder ad if not already loaded
  if (!popunderScript.value) {
    popunderScript.value = selectRandomPopunderProviderScript()
  }

  // Load push notification ad if not already loaded
  if (!pushScript.value) {
    pushScript.value = selectRandomPushAdProviderScript()
  }

  // Load selected ads
  useHead({
    script: [
      {
        src: popunderScript.value,
        async: false,
        defer: true,

        // Fix for CORS issues - https://unhead.unjs.io/usage/composables/use-script#referrerpolicy-and-crossorigin
        crossorigin: 'anonymous'
      },
      {
        src: pushScript.value,
        async: false,
        defer: true,

        crossorigin: 'anonymous'
      }
    ]
  })
}

export function useChatWithAiReferral() {
  const chatWithAiReferralTemplate = useState<string>('chat-with-ai-referral', () => '')

  const chatWithAiReferrals = [
    /**
     * CrushOn
     * Pros:
     * Cons:
     */
    {
      id: 'https://crushon.ai/search?s={query}&ref=zdnmmzy&mist=1',
      weight: 0.3
    },
    /**
     * SpicyChat
     * Pros: More revenue ()
     * Cons:
     */
    {
      id: 'https://spicychat.ai/?public_characters_alias%2Fsort%2Fnum_messages_24h%3Adesc[query]={query}&ref=ode2nzn',
      weight: 0.7
    }
  ]

  if (!chatWithAiReferralTemplate.value) {
    const selectedReferral = randomWeightedChoice(chatWithAiReferrals)
    chatWithAiReferralTemplate.value = selectedReferral
  }

  return {
    chatWithAiReferralTemplate
  }
}
