<script setup>
  import { project } from '~~/config/project'

  const { t } = useI18n()
  const localePath = useLocalePath()

  useSeoMeta({
    title: computed(() => t('pages.legal.dmcaSeoTitle')),
    description: computed(() => t('pages.legal.dmcaDescription', { name: project.name }))
  })

  useSchemaOrg(() => [
    defineBreadcrumb({
      // Breadcrumb items stay locale-relative; production-absolute URLs are reserved for canonicals.
      itemListElement: [
        { name: t('nav.home'), item: localePath('/') },
        { name: t('pages.legal.dmca'), item: localePath('/dmca') }
      ]
    }),
    defineWebPage()
  ])
</script>

<template>
  <main class="richtext container mx-auto max-w-3xl flex-1 px-4 py-4 sm:px-6 lg:px-8">
    <PageHeader>
      <template #title>{{ $t('pages.legal.dmca') }}</template>
    </PageHeader>

    <div>
      <p>
        {{ project.name }} ({{ project.urls.production.toString() }}) is a search engine that indexes and links to
        content hosted on third-party websites. We do not host any content ourselves. If you believe that your
        copyrighted work has been infringed upon by a website that we link to, please follow these steps:
      </p>

      <ol>
        <li>
          <strong>Identify the Website Hosting the Content</strong>: Locate the specific website that is hosting the
          allegedly infringing content, it's usually indicated on the top of the page, or at the URL.
        </li>
        <li>
          <strong>Contact the Website Owner</strong>: As we do not host the content, you will need to contact the owner
          or administrator of the website hosting the content to request its removal. Most websites have a DMCA or
          copyright infringement process outlined on their site.
        </li>
      </ol>

      <p>
        Please note that {{ project.name }} cannot process DMCA notices or remove content from third-party websites. We
        are merely a search engine that indexes and links to content hosted elsewhere on the internet. If you have any
        further questions or concerns, please contact us at {{ project.email }}.
      </p>
    </div>
  </main>
</template>
